@extends('layouts.front')
@section('content')
    <section class="resources">
        <div class="container">
            <div class="row" style="text-align:center;">
                <div class="col-lg-6 col-md-6 col-12">
                    <img src="{{ asset('assets/images/resources/1.png') }}" alt="" width="50%">
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <img src="{{ asset('assets/images/resources/1.png') }}" alt="" width="50%">
                </div>
            </div>
        </div>
    </section>
@endsection