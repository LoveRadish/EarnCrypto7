@extends('layouts.front')
@section('content')
    <section class="leader_board">
        <div class="container">
            <div class="row" style="text-align:center;">
                <div class="col-lg-3 col-md-3 col-md-6 col-xs-12">
                    <div class="leader_board_title_div">
                        <h3>{{$langg->lang1562}}</h3>
                    </div>
                     <p>1. Alex Paim</p>
                </div>
                <div class="col-lg-3 col-md-3 col-md-6 col-xs-12">
                    <div class="leader_board_title_div">
                        <h3>{{$langg->lang1563}}</h3>
                    </div>
                     <p>1. Alex Paim</p>
                </div>
                <div class="col-lg-3 col-md-3 col-md-6 col-xs-12">
                    <div class="leader_board_title_div">
                        <h3>{{$langg->lang1564}}</h3>
                    </div>
                     <p>1. Alex Paim</p>
                </div>
                <div class="col-lg-3 col-md-3 col-md-6 col-xs-12">
                    <div class="leader_board_title_div">
                        <h3>{{$langg->lang1565}}</h3>
                    </div>
                     <p>1. Alex Paim</p>
                </div>
            </div>
        </div>
    </section>
@endsection