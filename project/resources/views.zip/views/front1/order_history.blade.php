@extends('layouts.front')
@section('content')
    <section class="order_history">
        <div class="container">
            <h2>{{ $langg->lang1591 }}</h2>
            <div class="no_history">
                <p>{{ $langg->lang1592 }}</p>
            </div>
        </div>
    </section>
@endsection